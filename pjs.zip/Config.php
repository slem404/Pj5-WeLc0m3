<?php
	error_reporting(E_ERROR);
	$smtpconfig 	= array(
		// add your multi smtp
		array(
			'hostname'	=> 'smtp-relay.gmail.com',
			'portsmtp'	=> 587,
			'username'	=> "xz1@enryevsite.com",
			'password'	=> "Mamang123@"
		),
	);
	$priority		= 1; //(1 = High, 2 = Medium, 3 = Low)
	$sleeprotat		= 0; // setelah mengirim 10 email maka smtp akan (after send 10 email , smtp a change to b)
	$sleeptime		= 5; // waktu jeda (time delay)
	$replacement	= 1;
	$fromname		= array(
		'Apple',
	);
	$frommail		= "{randomtextlow_8}@{randomtextlow_15}.{randomtextlow_8}.{randomtextlow_5}";
	$subject		= 'Your receipt from #Apple-ID';
	$mailist		= "target/e.txt";
	$msgfile		= "letter/im.html";
	$randurl		= array(
		'https://google.com/?={email}={randomnum_13}'
	);
	$fakename		= array(
		'dipake'	=> true,
		'fakename'	=> array(
			"customer@live.com",
		)
	);
	$replyto		= array(
		'dipake'	=> false,
		'replyto'	=> array(
			'name'	=> 'Customer Service',
			'mail'	=> 'cs@id.apple.com'
		),
	);
	$bodyalt		= false;
	//$encoding		= 'base64';
	$encoding		= 'quoted-printable'; // Options: "8bit", "7bit", "binary", "base64", and "quoted-printable".

	// sender config
	$exit_on_error	= false;
	$userremoveline	= false;
?>