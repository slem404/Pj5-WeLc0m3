<?php

date_default_timezone_set('Etc/UTC');
require_once __DIR__."/modul/Function.php";
require_once __DIR__."/modul/Coloring.php";
require_once __DIR__."/modul/Html2Text.php";
require_once __DIR__."/modul/PHPMailerAutoload.php";

require_once __DIR__."/Config.php";
$color = new Colors();
print $color->color("====[ WELLCOME ]=====\r\n", 'green');
print $color->color("-----------{ ", 'red', "white").$color->color("CONFIGURATION", "white").$color->color(" }-----------", "red", "white")."\r\n";;
print "\tEmail\t\t\t: $mailist\r\n";
print "\tLetter\t\t\t: $msgfile\r\n";
print "\tSleep\t\t\t: $sleeptime\r\n";
print "\tRotate\t\t\t: $sleeprotat\r\n";
print "\r\n";

// count Mailist
$file = file_get_contents($mailist);
if($file){
	$ext = explode("\n", trim(str_replace("\r", '', $file)));
	$count = count($ext);
	$smtpcur = 0;
	$urlcurr = 0;
	$smtpmax = count($smtpconfig);
	$smtptemp = array();
	// Looping. For check all SMTP
	print "Check ALL SMTP\r\n";
	foreach($smtpconfig as $curr => $smtpuse){
		print $smtpuse['username']." >> ";
		try{
			$smtp = new SMTP;
			$smtp->do_debug = 0;
			$curd = date_default_timezone_get();
			if(!isset($smtpuse['tlsok']) or $smtpuse['tlsok'] == false){
				if (!$smtp->connect($smtpuse['hostname'], $smtpuse['portsmtp'])){
					// error connect hostname
					print $smtp->getError()['error']." [REMOVED]\r\n";
					$smtp->quit(true);
					continue;
				}
				if (!$smtp->hello(gethostname())){
					print $smtp->getError()['error']." [REMOVED]\r\n";
					$smtp->quit(true);
					continue;
				}
				$e = $smtp->getServerExtList();
				if (array_key_exists('STARTTLS', $e)){
					$tlsok = $smtp->startTLS();
					if (!$tlsok){
						// failed get tls
						print 'Failed to start encryption: ' . $smtp->getError()['error']." [REMOVED]\r\n";
						$smtp->quit(true);
						continue;
					}
					if (!$smtp->hello(gethostname())){
						print('EHLO (2) failed: ' . $smtp->getError()['error']." [REMOVED]\r\n");
						$smtp->quit(true);
						continue;
					}
					$e = $smtp->getServerExtList();
				}
				if (array_key_exists('AUTH', $e)){
					if ($smtp->authenticate($smtpuse['username'], $smtpuse['password'])){
						print "OK\r\n";
						$smtpuse['tlsok'] = true;
						$smtptemp[] = $smtpuse;
					}
					else{
						print $smtp->getError()['error']." [REMOVED]\r\n";
						$smtp->quit(true);
						continue;
					}
				}
				else{
					print $smtp->getError()['error']." [REMOVED]\r\n";
					$smtp->quit(true);
					continue;
				}
			}
		}
		catch (Exception $e) {
			echo 'JANCOK SMTP MU ERROR: ' . $e->getMessage(), "\n";
			$smtp->quit(true);
			continue;
		}
		$smtp->quit(true);
	}
	// disini send
	$smtpconfig = $smtptemp;
	if(empty($smtpconfig)){
		print "SMTPMU BOSOK KABEH\r\n";
		die();
	}

	foreach($ext as $num => $email){
		$nm = $num+1;
		print "[".$color->color($nm.'/'.$count, 'blue')."]";
		$smtpuse = $smtpconfig[$smtpcur];
		$smtpcur++;
		$phone = CustomPhone();
		if($smtpuse['tlsok']){
			print "[".$color->color($smtpuse['username'], 'cyan')."]";
			print "[".$color->color("connected", 'yellow')."]";
			$mail = new PHPMailer;
			$mail->CharSet 	= 'utf-8';
			$mail->Encoding = $encoding;
			$mail->Format 	= 'fixed';
			$mail->IsSMTP();
			$mail->SMTPAuth = true;
			$mail->Host = $smtpuse['hostname'];
			$mail->Port = $smtpuse['portsmtp'];
			$mail->Priority = $priority;
			$mail->Username = $smtpuse['username'];
			$mail->Password = $smtpuse['password'];
			//$mail->isHTML(true);
			
			$smtpdom		= explode('@', $smtpuse['username']);
			if(isset($smtpdom[1])){
				$smtpdom = $smtpdom[1];
			}
			else{
				$smtpdom = '';
			}
			$fromnames  	= $fromname[array_rand($fromname)];
			$_frommails		= str_replace('{smtp_domain}', $smtpdom, $frommail);
			$_frommails		= lettering($_frommails);
			
			$_subjects		= str_replace('{custom_phone}', $phone, $subject);
			$_subjects		= lettering($_subjects);
			$fakenames		= explode('@', $email);
			$mail->setFrom($_frommails, $fromnames);
			if($fakename['dipake']){
				$mail->addAddress($email, $fakename['fakename'][array_rand($fakename['fakename'])]);
			}
			else{
				$mail->addAddress($email);
			}
			if($replyto['dipake']){
				$mail->addReplyTo($replyto['replyto']['mail'], $replyto['replyto']['name']);
			}
			$mail->Subject = $_subjects;
			$cururl = $randurl[$urlcurr];
			$urlcurr++;
			if(count($randurl) == $urlcurr){
				$urlcurr = 0;
			}
			$msg = file_get_contents($msgfile);
			$msg = str_replace('{link}', $cururl, $msg);
			
			$msg = str_replace('{email}', $email, $msg);
			$msg = str_replace('{custom_phone}', $phone, $msg);
			if($replacement==1){
				$msg = lettering($msg);
			}
			//$mail->Body = $msg;
			$mail->msgHTML($msg);
			if($bodyalt){
				$alt = preg_replace('/<font (.*?)transparent(.*?)<\/FONT>/i', '', $msg);
				$htex = new Html2Text();
				$htex->setHtml($alt);
				$mail->AltBody = $htex->getText();
			}
			date_default_timezone_set('Asia/Jakarta');
			$date = date('h:iA');
			date_default_timezone_set($curd);
			print "[".$color->color($date, 'light_blue')."]";
			if (!$mail->send()){
				$err = $mail->ErrorInfo;
				echo "ERROR : ".$err;
				file_put_contents('Failed.txt', "$email -> $err\r\n", FILE_APPEND);
				if($exit_on_error){
					exit();
				}
			}
			else{
				echo $color->color(" $email ", 'purple').$color->color(" Success", 'light_green');
			}
			$mail->clearAddresses();
			if($userremoveline){
				RemoveLine($mailist, $email);
			}
			if($nm < count($ext)){
				sleep($sleeptime);
			}
		}
		if($smtpcur == count($smtpconfig)){
			$smtpcur = 0;
			if($nm < count($ext)){
				print " [ROTATE]";
				sleep($sleeprotat);
			}
		}
		print "\r\n";
	}
}